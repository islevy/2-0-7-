/*
Navicat MySQL Data Transfer

Source Server         : sql
Source Server Version : 50537
Source Host           : 127.0.0.1:3306
Source Database       : booking

Target Server Type    : MYSQL
Target Server Version : 50537
File Encoding         : 65001

Date: 2018-12-03 14:59:18
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_authority` int(11) NOT NULL,
  `admin_password` varchar(20) NOT NULL DEFAULT '123456',
  PRIMARY KEY (`admin_id`),
  KEY `admin_authority` (`admin_authority`),
  CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`admin_authority`) REFERENCES `station` (`station_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('0', 'admin', '0', '12');

-- ----------------------------
-- Table structure for legal_user
-- ----------------------------
DROP TABLE IF EXISTS `legal_user`;
CREATE TABLE `legal_user` (
  `legal_id` int(11) NOT NULL AUTO_INCREMENT,
  `legal_name` varchar(255) NOT NULL,
  `legal_idnum` varchar(255) NOT NULL,
  PRIMARY KEY (`legal_id`),
  KEY `legal_idnum` (`legal_idnum`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of legal_user
-- ----------------------------
INSERT INTO `legal_user` VALUES ('1', '赵佳然', '20182024');
INSERT INTO `legal_user` VALUES ('2', '梁洁雅', '20182029');
INSERT INTO `legal_user` VALUES ('3', '彭思', '20182016');
INSERT INTO `legal_user` VALUES ('4', '李威', '20182014');
INSERT INTO `legal_user` VALUES ('5', '王乐', '20182027');

-- ----------------------------
-- Table structure for record
-- ----------------------------
DROP TABLE IF EXISTS `record`;
CREATE TABLE `record` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `record_ticket_id` int(11) NOT NULL,
  `record_user_id` int(11) NOT NULL,
  `record_book_time` datetime NOT NULL,
  `record_state` tinyint(8) NOT NULL,
  PRIMARY KEY (`record_id`),
  KEY `record_ticket_id` (`record_ticket_id`),
  KEY `record_user_id` (`record_user_id`),
  CONSTRAINT `record_ibfk_1` FOREIGN KEY (`record_ticket_id`) REFERENCES `ticket` (`ticket_id`),
  CONSTRAINT `record_ibfk_2` FOREIGN KEY (`record_user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of record
-- ----------------------------

-- ----------------------------
-- Table structure for station
-- ----------------------------
DROP TABLE IF EXISTS `station`;
CREATE TABLE `station` (
  `station_id` int(11) NOT NULL AUTO_INCREMENT,
  `station_city` varchar(255) NOT NULL,
  `station_ip` varchar(255) NOT NULL,
  PRIMARY KEY (`station_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of station
-- ----------------------------
INSERT INTO `station` VALUES ('0', 'system', '0.0.0.0');
INSERT INTO `station` VALUES ('1', '北京', '1.1.1.1');
INSERT INTO `station` VALUES ('2', '上海', '2.2.2.2');
INSERT INTO `station` VALUES ('3', '太原', '3.3.3.3');

-- ----------------------------
-- Table structure for ticket
-- ----------------------------
DROP TABLE IF EXISTS `ticket`;
CREATE TABLE `ticket` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_train_num` varchar(50) NOT NULL,
  `ticket_seat_num` varchar(10) NOT NULL,
  `ticket_train_date` date NOT NULL,
  `ticket_state` tinyint(8) NOT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `ticket_train_num` (`ticket_train_num`),
  CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`ticket_train_num`) REFERENCES `train` (`train_num`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ticket
-- ----------------------------

-- ----------------------------
-- Table structure for train
-- ----------------------------
DROP TABLE IF EXISTS `train`;
CREATE TABLE `train` (
  `train_id` int(11) NOT NULL AUTO_INCREMENT,
  `train_num` varchar(50) NOT NULL,
  `train_start_station` int(11) NOT NULL,
  `train_end_station` int(11) NOT NULL,
  `train_start_time` time NOT NULL,
  `train_last_hour` int(5) NOT NULL,
  `train_last_minute` int(2) NOT NULL,
  `train_price` int(16) NOT NULL,
  PRIMARY KEY (`train_id`),
  KEY `train_start_station` (`train_start_station`),
  KEY `train_end_station` (`train_end_station`),
  KEY `train_num` (`train_num`),
  CONSTRAINT `train_ibfk_1` FOREIGN KEY (`train_start_station`) REFERENCES `station` (`station_id`),
  CONSTRAINT `train_ibfk_2` FOREIGN KEY (`train_end_station`) REFERENCES `station` (`station_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of train
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_reallyname` varchar(255) NOT NULL,
  `user_idnum` varchar(255) NOT NULL,
  `user_tele` varchar(50) NOT NULL,
  `user_password` varchar(6) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `user_idnum` (`user_idnum`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`user_idnum`) REFERENCES `legal_user` (`legal_idnum`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
